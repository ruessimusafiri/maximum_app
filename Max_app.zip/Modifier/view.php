 
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.png" />

    <title>Artisanal</title>

   <!-- Bootstrap core CSS -->
    <link href="css2/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css2/bootstrap-theme.min.css" rel="stylesheet">
   

    
     <link rel="stylesheet" href="css2/style.css" rel="stylesheet">
     <link rel="stylesheet" href="css2/Normalize.css" rel="stylesheet">
     <link rel="stylesheet" href="css2/font-awesome/css/font-awesome.min.css">
     <script src="js2/jquery-1.11.3.min.js"></script>
  
  <script src="js2/bootstrap.min.js"></script>

    

    

     
        
  </head>
<body onload="execute()">


<?php 
 
  require_once "class_php/connect.php";
include 'nav.php';

 
 ?> 




<div class="container mainbg" style="margin-top:10px;">
<br><a class="return" href="artisanal.php"><i class="glyphicon glyphicon-arrow-left"></i> Retour</a>

    <h1 class="h1_title" style="background-color:gray;">Details </h1>
     
    <div class="row">

        <style>
            #customers {
              font-family: Arial, Helvetica, sans-serif;
              border-collapse: collapse;
              width: 100%;
            }
            
            #customers td, #customers th {
              border: 1px solid #ddd;
              padding: 8px;
            }
            
            #customers tr:nth-child(even){background-color: #f2f2f2;}
            
            #customers tr:hover {background-color: #ddd;}
            
            #customers th {
              padding-top: 12px;
              padding-bottom: 12px;
              text-align: left;
              background-color: #a9aca9;
              color: white;
            }
            </style>
            </head>
            <body>
            
           
            </div>
     
     
     <?php
      require_once 'class_php/conducteur.php';

      $conducteur=new conducteur();

      $result=$conducteur->card($_GET['id']);

    //  if(isset($_POST['search'])){
    // 	 $search=$_POST['search'];
    //  $result=$conducteur->card($_GET['id']);
    //  }else{
    //  $result=$conducteur->load_conducteur();
    //  }


   // $rst=$conducteur->load_conducteur();

    while($pst=$result->fetch()){

        ?>
        <img   src="<?php  echo $pst['file_picture']; ?>"  width="130"style="height:110px;" />
               <br> <br>
        <table id="customers">
                
            <tr>
              <th>Proprietaire</th>
              <th><?php  echo $pst['nom'].' '.$pst['postnom']; ?> </th> 
            </tr>
             
            
            <tr>
              <td> Sexe</td>
       
              <td> <?php  echo $pst['sexe'] ?></td>
            </tr>
            <tr>
                <td> Nationalité</td>
         
                <td> <?php  echo $pst['nationalite'] ?></td>
              </tr>
              <tr>
                <td> Type d'identification</td>
         
                <td> <?php  echo $pst['type_identification'] ?></td>
              </tr>
              <tr>
                <td> N° d'identification</td>
         
                <td> <?php  echo $pst['numero_id'] ?></td>
              </tr>
              <tr>
                <td> Adresse</td>
         
                <td> <?php  echo $pst['adresse_physique'] ?></td>
              </tr>
              <tr>
                <td> Marque</td>
         
                <td> <?php  echo $pst['marque'] ?></td>
              </tr>
              <tr>
                <td> N° chassis</td>
         
                <td> <?php  echo $pst['numero_chassis'] ?></td>
              </tr>
              <tr>
                <td> Année de fabrication</td>
         
                <td> <?php  echo $pst['annee_fab'] ?></td>
              </tr>
              <tr>
                <td> Année circulation</td>
         
                <td> <?php  echo $pst['annee_circulation'] ?></td>
              </tr>
              <tr>
                <td> Couleur</td>
         
                <td> <?php  echo $pst['couleur'] ?></td>
              </tr>
              <tr>
                <td> N° Moteur</td>
         
                <td> <?php  echo $pst['moteur'] ?></td>
              </tr>

          </table> <br>
          <a id="tr" data-toggle="modal" href="#infos<?php echo $pst['id']; ?>"  class="btn btn-danger">Confirmer paiement</a> 
          <a id="im" data-toggle="modal" href="#carte<?php echo $pst['id']; ?>"  class="btn btn-default"> Immatriculation</a> 
        
          <a  id="carte" href="proses.php?carte=<?php echo $pst['id']; ?>"   class="btn btn-primary">  <i class="fa fa-print"></i> Impression carte rose</a>
      
<?php
require_once 'class_php/conducteur.php';
$conducteur=new conducteur();
$get_it="";
$get_imm="";

$f=$conducteur->ver_paiement($pst['id']);
$im=$conducteur->ver_imm($pst['id']);

if($m=$im->fetch()){
$get_imm="1";
}else{
$get_imm="0";
}

if($s=$f->fetch()){
$get_it="1";
}else{
$get_it="0";
}
?>
<script>

function execute(){
var v1 = <?php echo json_encode($get_it); ?>;
var v2 = <?php echo json_encode($get_imm); ?>;
var elmt_tracabilite = document.getElementById("tr");
var elmt_im = document.getElementById("im");
var elmt_carte = document.getElementById("carte");
if(v1==1){
elmt_tracabilite.style.display = "none";

}else if(v1==0){
elmt_tracabilite.style.display = "";
elmt_carte.style.display = "none";
}
//
if(v2==1){
elmt_im.style.display = "none";
elmt_carte.style.display = "";
}else if(v2==0){
elmt_im.style.display = "";
elmt_carte.style.display = "none";
}

}

</script>   
<!-- confirme modal -->
            <div class="modal fade" id="infos<?php echo $pst['id']; ?>">
                <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">x</button>
                <h4 class="modal-title">Confirmation paiement </h4>
                </div>
                <form action="" method="post">
                <div class="modal-body">
                
                <div class="input-group">
                <span class="input-group-addon"><i class="fa fa-book"></i></span>
                <input type="text" name="preuve" class="form-control" placeholder="N° Preuve paiement" required=""> <br>
                
                </div>
                
                </div>
                <div class="modal-footer">
                <button type="submit" name="val" class="btn btn-info"  >Valider</button>
                </div>
                </form>
                </div>
                </div>
                </div>  
                <?php
                require_once 'class_php/conducteur.php';
                $date=date('d:m:yy');
                $conducteur=new conducteur();
                if(isset($_POST['val'])){
                    $id=$pst['id'];
                $conducteur->confirmer_paiement($pst['id'],$_POST['preuve'],$date);
                echo "<meta http-equiv='refresh' content='0; url = view.php?id=$id' />"; 
                
                }
                
                ?>
                <!-- attribution carte rose -->
                <div class="modal fade" id="carte<?php echo $pst['id']; ?>">
                    <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">x</button>
                    <h4 class="modal-title">Plaque d'Immatriculation</h4>
                    </div>
                    <form action="" method="post">
                    <div class="modal-body">
                    
                    <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-book"></i></span>
                    <input type="text" name="plaque" class="form-control" placeholder="N° Plaque d'Immatriculation" required=""> <br>
                    
                    </div>
                    
                    </div>
                    <div class="modal-footer">
                    <button type="submit" name="im" class="btn btn-info"  >Valider</button>
                    </div>
                    </form>
                    </div>
                    </div>
                    </div>  

                    <?php
                require_once 'class_php/conducteur.php';
                $date=date('d:m:yy');
                $conducteur=new conducteur();
                if(isset($_POST['im'])){
                    $id=$pst['id'];
                $conducteur->plaque_immatriculation($pst['id'],$_POST['plaque'],$date);
                echo "<meta http-equiv='refresh' content='0; url = view.php?id=$id' />";
                
                
                
                }
                
                ?>
        <?php
    }
?>
<!-- <a  data-toggle="modal" href="#infos"  class="btn btn-default"> <i class="fa fa-eye"></i> </a>                       -->

    

        <!-- <li class="nav-item">
          <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Cooperative</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" data-toggle="tab" href="#laboratoire" role="tab"> Négociant</a>
        </li> -->
        
 <!-- details -->
  

 <!----------------------------------------tab2---------------------------------------------------------------------------->
  

 <div class=" " role=" ">
        <div class="tab-pane active" id="home" role="tabpanel">
        <br>
        
         
              
         
 </div>
 
 <br>
   
 <!-- <?php include 'footer.php'; ?>                            -->
 <script src="js/bootstrap.min.js"></script>          
<script src="js/popper.min.js"></script>
<script src="js/jquery-slim.min.js"></script>
<script src="js/tab.js"></script>
<script src="js/util.js"></script>


  </body>
</html>
