 
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.png" />

    <title>Artisanal</title>

   <!-- Bootstrap core CSS -->
    <link href="css2/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css2/bootstrap-theme.min.css" rel="stylesheet">
   

    
     <link rel="stylesheet" href="css2/style.css" rel="stylesheet">
     <link rel="stylesheet" href="css2/Normalize.css" rel="stylesheet">
     <link rel="stylesheet" href="css2/font-awesome/css/font-awesome.min.css">
     <script src="js2/jquery-1.11.3.min.js"></script>
  
  <script src="js2/bootstrap.min.js"></script>

    

    

     
        
  </head>
<body>


<?php 
 
  require_once "class_php/connect.php";
include 'nav.php';

 
 ?> 




<div class="container mainbg" style="margin-top:10px;">
<br><a class="return" href="accueil.php"><i class="glyphicon glyphicon-arrow-left"></i> Retour</a>

    <h1 class="h1_title" style="background-color:gray;">Province d'activité</h1>
    <hr> <br>
 

    <div class="clear"></div>
    <div class="row col-md-10 col-md-offset-1">

    
    

        <!-- <li class="nav-item">
          <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Cooperative</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" data-toggle="tab" href="#laboratoire" role="tab"> Négociant</a>
        </li> -->
        
 <!-- details -->
  

 <!----------------------------------------tab2---------------------------------------------------------------------------->

<div class="modal fade" id="artisanal"> 
     <div class="modal-dialog">    
         <div class="modal-content">      
             <div class="modal-header">
<button type="button" class="close" data-dismiss="modal">x</button>        
<h4 class="modal-title">Ajout province</h4>      
</div>      
<div class="modal-body">  
<form action="" method="post" enctype="multipart/form-data" >
                                     

                                     <label class="">Province <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;"></span></label>
                             <div class="input-group"> 
                 <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                
                 <select name="province" class="form-control"   required>
                 <option  value="">Selecionner</option> 
                 <option >Bas-Uele</option>
                 <option>Equateur</option>
                   <option>Haut Katanga</option>
                    <option>Haut lomami</option>
                    <option>Haut Uele</option>
                    <option>Ituri</option>
                    <option>Kasai</option>
                    <option>Kasai Central</option>
                    <option>Kasai oriental</option>
                    <option>Kinshasa</option>
                    <option>Kongo Central</option>
                    <option>Kwango</option>
                    <option>Kwilu</option>
                    <option>Lomami</option>
                    <option>Lualaba</option>
                    <option>Mai Ndombe</option>
                    <option>Maniema</option>
                    <option>Mongala</option>
                    <option>Nord Kivu</option>
                    <option>Nord Ubangi</option>
                    <option>Sankuru</option>
                    <option>Sud Kivu</option>
                    <option>Sud Ubangi</option>
                    <option>Tanganyika</option>
                    <option>Tshopo</option>
                    <option>Tshuapa</option>
 
                 </select>
 
 
             </div><br>
 
 
                                      <div class="input-group">
                                          <label for="">Logo <label for="" style="color: red;">(importer l'image du logo)</label></label>
                                      <!-- <span class="input-group-addon"><i class="fa fa-lock"></i></span> -->
                                      <input type="file" name="logo" class="form-control"  required="" >
                                      </div>
                                      <br> 
             <button type="submit" class="btn btn-primary" name="save_prov">ENREGISTRER</button>
                                      
                   </form> 
</div> <div class="modal-footer">
   
           
</div>   
  
 </div>  
</div> 
</div>

<?php

require_once 'class_php/utilisateur.php';
require_once 'class_php/connect.php';
require_once 'class_php/province_class.php';

$province=new province($connect);

if(isset($_POST['save_prov'])){

    $filename = $_FILES['logo']['name']; 
    $filetmpname = $_FILES['logo']['tmp_name']; 
    //folder where images will be uploaded 
    $folder = 'images/'; 

    $name_file=$folder.'_'.$_POST['province'].$filename;

    //function for saving the uploaded images in a specific folder 'CV'.$_POST['nom'].$_POST['postnom'].$_POST['telephone']
    move_uploaded_file($filetmpname, $folder.'_'.$_POST['province'].$filename); 

    $province->_province=$_POST['province'];
    $province->_logo=$name_file; 
    $province->new_province();

    // echo "<div class='alert alert-success center' style='width: 90%; margin: auto;'><p>vous avez supprimé avec succés</p></div><br><br>"; 
    // echo '<script type="text/javascript"> window.location.href += "#success"; </script>';
    echo "<meta http-equiv='refresh' content='1; url = parametre.php' />";

}

?>


 <div class=" " role=" ">
        <div class="tab-pane active" id="home" role="tabpanel">
        <br>
        <button  data-toggle="modal" href="#artisanal"    class="btn btn-primary" name="btn">Ajouter</button> <br>
        <form method="post" action=""> 

<br>
<div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-search"></i></span>
                  <input name="search" type="text" placeholder="recherche rapide" class="form-control validate[required]" />
               </div><br>


               
</form>
               
<table class="table table-striped table-bordered">
            <tr class="tr-table">
              <th>Province</th>
              <th>Logo</th>
               
              
             <th colspan="2">Action</th>
            </tr>
       <div class="row container">
  
       <?php
    
        require_once 'class_php/province_class.php';
        require_once 'class_php/connect.php';

        $province=new province($connect); 
        $rs=$province->load_province();  
        while ($r=$rs->fetch()){
             
          ?>
  
          <tr>
          <td><?php echo $r['province'] ?></td>
          <td> <img src="<?php echo $r['url_logo'] ?>"  width="50"></td>
         
          <td><a  data-toggle="modal" href="#infos"  class="btn btn-default"> <i class="fa fa-edit"></i> </a></td>
          <td><a href="#" class="btn btn-default"> <i class="fa fa-trash"></i> </a></td>
          </tr>
      
        
        <?php
        }
       ?> 
  
       </div>
  
       </table>
      
 </div>
 
 <br>                   
 <script src="js/bootstrap.min.js"></script>          
<script src="js/popper.min.js"></script>
<script src="js/jquery-slim.min.js"></script>
<script src="js/tab.js"></script>
<script src="js/util.js"></script>


  </body>
</html>
