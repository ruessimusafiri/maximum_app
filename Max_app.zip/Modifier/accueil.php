 
<!DOCTYPE html>
<html lang="zxx">
	<head>
		<!-- Meta Tag -->
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name='copyright' content='pavilan'>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
		<!-- Title Tag  -->
		<title>Maximum b</title>
		
		<!-- Favicon -->
		<!-- <link rel="icon" type="images/logo.png" href="images/"> -->
		
		<!-- Web Font -->
		<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
		
		<!-- Bizwheel Plugins CSS -->
		<link rel="stylesheet" href="css/animate.min.css">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<link rel="stylesheet" href="css/cubeportfolio.min.css">
		<link rel="stylesheet" href="css/font-awesome.css">
		<link rel="stylesheet" href="css/jquery.fancybox.min.css">
		<link rel="stylesheet" href="css/magnific-popup.min.css">
		<link rel="stylesheet" href="css/owl-carousel.min.css">
		<link rel="stylesheet" href="css/slicknav.min.css">

		<!-- Bizwheel Stylesheet -->  
		<link rel="stylesheet" href="css/reset.css">
		<link rel="stylesheet" href="style.css">
		<link rel="stylesheet" href="css/responsive.css">

		<link rel="stylesheet" href="fonta/css/all.css">
		
		<!-- Bizwheel Colors -->
		<!-- <link rel="stylesheet" href="css/skins/skin-1.css"> -->
 
		 
		
		<!--[if lt IE 9]>
			<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.2/html5shiv.min.js"></script>
			<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
		
	</head>
	<body id="bg">
	
		<!-- Boxed Layout -->
		<div id="page" class="site boxed-layout"> 
		
		<!-- Preloader -->
		<div class="preeloader">
			<div class="preloader-spinner"></div>
		</div>
		<!--/ End Preloader -->
	
		<!-- Header -->
		<header class="header">
			<!-- Topbar -->
			 
			<!--/ End Topbar -->
			<!-- Middle Header -->
			<div class="middle-header">
				<div class="container">
					<div class="row">
						<div class="col-12">
							<div class="middle-inner">
								<div class="row">
									<div class="col-lg-2 col-md-3 col-12">
										<!-- Logo -->
										 								
										<div class="mobile-nav"></div>
									</div>
									<div class="col-lg-10 col-md-9 col-12">
										<div class="menu-area">
											<!-- Main Menu -->
											<nav class="navbar navbar-expand-lg">
												<div class="navbar-collapse">	
													<div class="nav-inner">	
														<div class="menu-home-menu-container">
															<!-- Naviagiton -->
															<ul id="nav" class="nav main-menu menu navbar-nav">
																<!-- <li><a href="index.html">Home</a></li>
																<li><a href="services.html">Our Services</a></li>
																<li><a href="portfolio.html">Our Portfolio</a></li>
																<li class="icon-active"><a href="#">Blog</a>
																	<ul class="sub-menu">
																		<li><a href="blog.html">Blog Grid</a></li>
																		<li><a href="blog-single.html">Blog Single</a></li>
																	</ul>
																</li> -->
																<!-- <li class="icon-active"><a href="#">Pages</a>
																	<ul class="sub-menu">
																		<li><a href="about.html">About Us</a></li>
																		<li><a href="404.html">404</a></li>
																	</ul>
																</li> -->
																 
																<li><a href="index.php">Se deconnecter</a></li>
															</ul>
															<!--/ End Naviagiton -->
														</div>
													</div>
												</div>
											</nav>
											<!--/ End Main Menu -->	
											<!-- Right Bar -->
											<div class="right-bar">
												<!-- Search Bar -->
												<ul class="right-nav">
													<!-- <li class="top-search"><a href="#0"><i class="fa fa-search"></i></a></li> -->
													<li class="bar"><a class="fa fa-bars"></a></li>
												</ul>
												<!--/ End Search Bar -->
												<!-- Search Form -->
												  
												<!--/ End Search Form -->
											</div>	
											<!--/ End Right Bar -->
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--/ End Middle Header -->
			<!-- Sidebar Popup -->
			<div class="sidebar-popup">
				<div class="cross">
					<a class="btn"><i class="fa fa-close"></i></a>
				</div>
				<div class="single-content">
					<h4>SEIM</h4>
					<p></p>
					<!-- Social Icons -->
					<!-- <ul class="social">
						<li><a href="artisanal.php?id=<?php echo $code; ?>"><i class="fa fa-podcast"></i></a></li>
						<li><a href="cooperative.php?id=<?php echo $code; ?>"><i class="fa fa-contao"></i></a></li>
						<li><a href="negociant.php?id=<?php echo $code; ?>"><i class="fa fa-bandcamp"></i></a></li>
						<li><a href="index.php?id=<?php echo $code; ?>"><i class="fa fa-user"></i></a></li>
					</ul> -->
				</div>
				<div class="single-content">
					<!-- <h4>Declarant</h4>    -->
					<!-- <ul class="links">
						<li><a href="artisanal.php?id=<?php echo $code; ?>">Artisanal</a></li>
						<li><a href="cooperative.php?id=<?php echo $code; ?>">Cooperative</a></li>
						<li><a href="negociant.php?id=<?php echo $code; ?>">Negociant</a></li> 
						 
						<li><a href="index.php?id=<?php echo $code; ?>">Se deconnecter</a></li> -->
					</ul>
				</div>	
			</div>
			<!--/ Sidebar Popup -->	
		</header>
		<!--/ End Header -->
		
		<!-- Hero Slider style="height: 200px;" -->
		<section class="hero-slider style1" >
			<div class="home-slider"  >
				<!-- Single Slider -->
				<div class="single-slider" style="background-image:url('img/bg-01.jpg');height: 250px;" >
					<div class="container">
						<div class="row">
							<div class="col-lg-7 col-md-8 col-12">
								<div class="welcome-text"> 
									<div class="hero-text"> 
									
										
										<h4 style="font-size:25px;">Bienvenue   dans l'application d'enregistrement d'immatriculation moto</h4>
										<h1> </h1>
										<div class="p-text">
											<!-- <p>Nunc tincidunt venenatis elit. Etiam venenatis quam vel maximus bibendum Pellentesque elementum dapibus diam tristique</p> -->
										</div>
										<div class="button">
											<!-- <a href="contact.html" class="bizwheel-btn theme-1 effect">Work with us</a>
											<a href="portfolio.html" class="bizwheel-btn theme-2 effect">View Our Portfolio</a> -->
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!--/ End Single Slider -->
				<!-- Single Slider -->
				<!-- <div class="single-slider" style="background-image:url('img/bg-1.jpg');height: 250px;">
					<div class="container">
						<div class="row">
							<div class="col-lg-7 col-md-8 col-12">
								<div class="welcome-text"> 
									<div class="hero-text"> 
										<h4>Your time is so important for us</h4>
										<h1>Build Your WorldClass Brand with Bizwheel</h1>
										<div class="p-text">
											<p>Nunc tincidunt venenatis elit. Etiam venenatis quam vel maximus bibendum Pellentesque elementum dapibus diam tristique</p>
										</div>
										<div class="button">
											<a href="blog.html" class="bizwheel-btn theme-1 effect">Read our blog</a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div> -->
				<!--/ End Single Slider -->
				<!-- Single Slider -->
				 
				<!--/ End Single Slider -->
			</div>

			<div class="container">
				<div class="row">
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Single Feature -->
						<a  href="artisanal.php">
						<div class="single-feature active">
							<div class="icon-head"><i class="fa fa-bicycle"></i></div>
							<h4><a href="artisanal.php" >Proprietaire</a></h4>
							<!-- <p>Possibilité d'enregistrer des proprietaires</p> -->
								<div class="button">
								<a href="artisanal.php" class="bizwheel-btn"><i class="fa fa-arrow-circle-o-right"></i>Acceder</a>
							</div>
						</div>

						</a>
						
						<!--/ End Single Feature -->
					</div>
				 
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Single Feature -->
						<a  href="utilisateur.php"  >
						<div class="single-feature ">
							<div class="icon-head"><i class="fa fa-user-tie"></i> </div>
							<h4><a  href="utilisateur.php" >Utilisateur</a></h4>
							<!-- <p>Créer utilisateurs </p> -->
							<div class="button">
								<a  href="utilisateur.php"  class="bizwheel-btn"><i class="fa fa-arrow-circle-o-right"></i>Acceder</a>
							</div>
						</div></a>
						<!--/ End Single Feature -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Single Feature -->
						<a href="parametre.php"	>
						<div class="single-feature">
							<div class="icon-head"><i class="fa fa-cogs">!</i></div>
							<h4><a  href="parametre.php">Parametre</a></h4>
							<!-- <p>Se deconecter de votre application</p> -->
							<div class="button">
								<a  href="parametre.php" class="bizwheel-btn"><i class="fa fa-arrow-circle-o-right"></i>Parametre</a>
							</div>
						</div></a>
						<!--/ End Single Feature -->
					</div>
					<div class="col-lg-3 col-md-6 col-12">
						<!-- Single Feature -->
						<a 	href="index.php">
						<div class="single-feature">
							<div class="icon-head"><i class="fa fa-user"></i></div>
							<h4><a href="index.php" >Deconnecter</a></h4>
							<!-- <p>Se deconecter de votre application</p> -->
							<div class="button">
								<a href="index.php"  class="bizwheel-btn"><i class="fa fa-arrow-circle-o-right"></i>Deconnecter</a>
							</div>
						</div></a>
						<!--/ End Single Feature -->
					</div>
					
				</div>
				
			</div>
		</section>
		<!--/ End Hero Slider -->
		
	 
		
		 
	
	</body>

		<!-- Jquery JS -->
		<script src="js/jquery.min.js"></script>
		<script src="js/jquery-migrate-3.0.0.js"></script>
		<!-- Popper JS -->
		<script src="js/popper.min.js"></script>
		<!-- Bootstrap JS -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Modernizr JS -->
		<script src="js/modernizr.min.js"></script>
		<!-- ScrollUp JS -->
		<script src="js/scrollup.js"></script>
		<!-- FacnyBox JS -->
		<script src="js/jquery-fancybox.min.js"></script>
		<!-- Cube Portfolio JS -->
		<script src="js/cubeportfolio.min.js"></script>
		<!-- Slick Nav JS -->
		<script src="js/slicknav.min.js"></script>
		<!-- Slick Nav JS -->
		<script src="js/slicknav.min.js"></script>
		<!-- Slick Slider JS -->
		<script src="js/owl-carousel.min.js"></script>
		<!-- Easing JS -->
		<script src="js/easing.js"></script>
		<!-- Magnipic Popup JS -->
		<script src="js/magnific-popup.min.js"></script>
		<!-- Active JS -->
		<script src="js/active.js"></script>
</html>