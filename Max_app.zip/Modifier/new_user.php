<?php
require 'connect.php';
function get_type_user($user){

$type1="Utilisateur";
$type2="Administrateur";
if($user==$type1){

return 0;
}else if($user==$type2){

return 1;
}


}

function set_id_user_simple($type){

  if($type=="Autoriser"){

    return 1;
  }else if($type=="Utilisateur"){
    return 0;
  }
}
function set_id_gest_user($type){

  if($type=="Autoriser"){

    return 1;
  }else if($type=="Gestion utilisateurs"){
    return 0;
  }
}

function set_id_stat($type){

  if($type=="Autoriser"){

    return 1;
  }else if($type=="Statistiques"){
    return 0;
  }
}

function set_tracabilite($type){

  if($type=="Autoriser"){

    return 1;
  }else if($type=="Tracabilité"){
    return 0;
  }
}
function set_setting($type){

  if($type=="Autoriser"){

    return 1;
  }else if($type=="Configuration"){
    return 0;
  }
}
    if(isset($_GET['add_user'])){

    $user_simple= set_id_user_simple($categorie=$_GET['categorie']);
    $gest_user=set_id_gest_user($user=$_GET['user']);
   $stat= set_id_stat($statistique=$_GET['stat']);
   $traca=set_tracabilite($tracabilite=$_GET['tracabilite']);
 $set=set_setting($config=$_GET['setting']);

      $username=$_GET['username'];
      $email=$_GET['email'];
      $password=$_GET['password'];
      $Confirmer_pass=$_GET['password_confirme'];
      
      $direction=$_GET['direction'];

      $date_user=date('d:m:y');

      $code=0;

//    

      if($password==$Confirmer_pass){

          $cat=get_type_user($categorie);

        $insert="INSERT INTO login(`username`, `password`, `email`, `utilisateur_simple`, `gestion_user`, `tracabilite`, `statistique`, `setting`, `statut`, `direction`, `date_user`)
         VALUES ('$username','$Confirmer_pass','$email','$user_simple','$gest_user','$traca',' $stat','$set','','$direction','$date_user')";

         $execute=$connect->query($insert);

  echo "<meta http-equiv='refresh' content='0; url = user_panel.php?id=0' />";

 
    ;




      }else{
        echo "<div class='alert alert-danger center' style='width: 50%; margin: auto;'><p    align='center'>Le mot de passe doit est identique</p></div><br><br>"; 
      }


    }

    ?> 