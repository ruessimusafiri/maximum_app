<div id="footer">
  Copyright &copy; <?php echo date("Y"); ?> | <a href="http://www.genisys.net" title="cliquez sur le lien pour acceder a notre site web">Genisys_Corp</a> - Application de gestion de perception des frais en rénumeration de services rendus (FRSR)  BY <i>J-didier IHETA (CD / Analyse,conception et developpement)</i>
</div>   