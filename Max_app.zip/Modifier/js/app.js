// JavaScript Document
(function(s){
	$('.addPanier.').click(function(event)
	{
		//event.preventDefault();
		alert('bonjour');
	})
})(jQuery);