<?php
	if(isset($_GET['carte'])){
		require_once('fpdf/Code39.php');

		require_once 'class_php/conducteur.php';

		$conducteur=new conducteur(); 
		$result=$conducteur->card($_GET['carte']);
		$pst=$result->fetch();

		$r=$conducteur->load_plaque($_GET['carte']);
		$p=$r->fetch();

		$pdf = new PDF_Code39();
		$pdf->AddPage();
		$pdf->Image('images/face_a.jpg', 10, 10,100, 60);

		$pdf->AddFont('courier','','courier.php');	
		$pdf->SetFont('courier','b',11);
		$pdf->SetXY(10.5, 31.4);
		$pdf->SetFont('Arial','B',7);
		$pdf->Cell(9.5,7,$p['num_plaque'],0,4,'L');
		// $pdf->SetXY(55, 33);
		// $pdf->Cell(9.5,7,'Nom',0,4,'L');
		$pdf->SetXY(10.5, 39.5);
		$pdf->Cell(9.5,7,$pst['nom'].' '.$pst['postnom'],0,4,'L');
		$pdf->SetXY(10.5, 48);
		$pdf->Cell(9.5,7,$pst['adresse_physique'],0,4,'L');
		$pdf->SetXY(57.5, 31.5);
		$pdf->Cell(9.5,7,$pst['annee_circulation'],0,4,'L');


		//second**

		
		$pdf->Image('images/face_b.jpg', 10, 100,100, 60);
		$pdf->SetXY(10.5, 121.5);
		$pdf->Cell(9.5,7,$pst['marque'],0,4,'L');

		$pdf->SetXY(10.5, 129.5);
		$pdf->Cell(9.5,7,$pst['numero_chassis'],0,4,'L');
 
		$pdf->SetXY(10.5, 137.5);
		$pdf->Cell(9.5,7,$pst['annee_fab'],0,4,'L');

		//type
		$pdf->SetXY(60.5, 121.5);
		$pdf->Cell(9.5,7,$pst['type_moto'],0,4,'L');

		$pdf->SetXY(60.5, 129.5);
		$pdf->Cell(9.5,7,$pst['moteur'],0,4,'L');

		//couleur
		$pdf->SetXY(10.5, 145.5);
		$pdf->Cell(9.5,7,$pst['couleur'],0,4,'L');

 
 
		//$pdf->Image('images/depan_cetak.jpg', 10,65,180, 50); annee_circulation
		// $pdf->AddFont('courier','','courier.php');	
		// $pdf->SetFont('courier','b',11);
		// $pdf->SetXY(55, 29+55);
		// $pdf->SetFont('Arial','B',7);
		// $pdf->Cell(9.5,7,$nomor,0,4,'L');
		// $pdf->SetXY(55, 33+55);
		// $pdf->Cell(9.5,7,$nama,0,4,'L');
		// $pdf->SetXY(55, 40+55);
		// $pdf->Cell(9.5,7,$jk,0,4,'L');
		// $pdf->SetXY(55, 44+55);
		// $pdf->Cell(9.5,7,$tempat,0,4,'L');
		// $pdf->SetXY(55, 48+55);
		// $pdf->Cell(9.5,7,$tanggal,0,4,'L');

		$pdf->Output();
	}
?>