
			<link href="css2/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css2/bootstrap-theme.min.css" rel="stylesheet">
   
    
        <!-- Bizwheel Stylesheet -->  
        <link rel="stylesheet" href="css/reset.css">
        <link rel="stylesheet" href="style.css">
       <!--  <link rel="stylesheet" href="css/responsive.css"> -->
       
        <!-- Bizwheel Colors -->
      <!--   <link rel="stylesheet" href="css/skins/skin-1.css">
 
        <link rel="stylesheet" href="fonta/css/all.css"> -->
        

        <link href="css2/bootstrap.min.css" rel="stylesheet">

<!-- Bootstrap theme -->
<link href="css2/bootstrap-theme.min.css" rel="stylesheet"> 
  
 <link rel="stylesheet" href="css2/Normalize.css" rel="stylesheet">
 <link rel="stylesheet" href="css2/font-awesome/css/font-awesome.min.css"> 
  <script src="js2/jquery-1.11.3.min.js"></script>

  <link href="css2/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css2/bootstrap-theme.min.css" rel="stylesheet">
   

    
     <link rel="stylesheet" href="css2/style.css" rel="stylesheet">
     <link rel="stylesheet" href="css2/Normalize.css" rel="stylesheet">
     <link rel="stylesheet" href="css2/font-awesome/css/font-awesome.min.css">
     <script src="js2/jquery-1.11.3.min.js"></script>
  
  <script src="js2/bootstrap.min.js"></script>

            <!-- Topbar -->
			 
			<!--/ End Topbar -->
			<!-- Middle Header -->
			<div class="middle-header">
				<div class="container">
					<div class="row">
						<div class="col-12">
							<div class="middle-inner">
								<div class="row">
									<div class="col-lg-2 col-md-3 col-12">
										<!-- Logo -->
										 				 				
										<div class="mobile-nav"></div>
									</div>
									<div class="col-lg-10 col-md-9 col-12">
										<div class="menu-area">
											<!-- Main Menu -->
											<nav class="navbar navbar-expand-lg">
												<div class="navbar-collapse">	
													<div class="nav-inner">	
														<div class="menu-home-menu-container">
															<!-- Naviagiton -->
															<ul id="nav" class="nav main-menu menu navbar-nav">
																<!-- <li><a href="index.html">Home</a></li>
																<li><a href="services.html">Our Services</a></li>
																<li><a href="portfolio.html">Our Portfolio</a></li>
																<li class="icon-active"><a href="#">Blog</a>
																	<ul class="sub-menu">
																		<li><a href="blog.html">Blog Grid</a></li>
																		<li><a href="blog-single.html">Blog Single</a></li>
																	</ul>
																</li> -->
																<!-- <li class="icon-active"><a href="#">Pages</a>
																	<ul class="sub-menu">
																		<li><a href="about.html">About Us</a></li>
																		<li><a href="404.html">404</a></li>
																	</ul>
																</li> -->
																 
																<!-- <li><a href="index.php">Se deconnecter</a></li> -->
															</ul>
															<!--/ End Naviagiton -->
														</div>
													</div>
												</div>
											</nav>
											<!--/ End Main Menu -->	
											<!-- Right Bar -->
											<div class="right-bar">
												<!-- Search Bar -->
												<ul class="right-nav">
													<!-- <li class="top-search"><a href="#0"><i class="fa fa-search"></i></a></li> -->
													<li class="bar"><a href="index.php" class="fa fa-user"></a></li>
												</ul>
												<!--/ End Search Bar -->
												<!-- Search Form -->
												  
												<!--/ End Search Form -->
											</div>	
											<!--/ End Right Bar -->
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
	 