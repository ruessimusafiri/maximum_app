
<div class="nav">

	<div class="navbar navbar-default navbar-fixed-top">
      
        <div class="container">
          
            <div class="navbar-header">

                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">    
                        <span class="sr-only">Toggle navigation</span>      
                        <span class="icon-bar"></span>  
                        <span class="icon-bar"></span>  
                        <span class="icon-bar"></span>          
                </button> 

                <h2 class="h1_title">SAEMAPE | FRSR <!-- <img src="image/" alt="image" width="30" height="30"/> --></h2>

           </div>

            <div class="collapse navbar-collapse nav_right">
                                        
				<div class="btn-group">
 <button  type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

 <?php

// $codes=$_GET['id'];
 ?>
				     <a href="UI.php" ><i class="glyphicon glyphicon-home large"></i></a> 
				  </button>
				</div>

				

             </div>

        </div>

    </div>

</div>

<div class="clear"></div>




