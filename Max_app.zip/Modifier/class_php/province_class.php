<?php

class province
{
    public $_id;
    public $_province;
    public $_logo;
    public $_db_connect;

    function __construct($db)
    {
        $this->_db_connect=$db;
    }

    function load_province()
    {
        return $this->request_query("select * from province");
    }
    function get_province($id)
    {
        $r=$this->request_query("select * from province where id='$id'"); 
        $pst=$r->fetch();

        return $pst['province'];
    }
    function new_province()
    {
        return $this->request_query("INSERT INTO `province`(`province`, `url_logo`) VALUES ('$this->_province','$this->_logo')");
    }

    function request_query($query)
    {
        return $this->_db_connect->query($query);

    }
}

?>