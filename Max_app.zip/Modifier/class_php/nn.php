<?php


class utilisateur{

    public $i_id;
    public $_email;
    public $_password;
    public $_id_province;
    public $_db_connect;

    function __construct($db)
    { 
        $this->_db_connect=$db; 
    }

    function load_user()
    {
        return $this->request_query('select * from user');
    }
    
    function new_user()
    {
        return $this->request_query("INSERT INTO `user`(`username`, `password`, `id_province`) VALUES ('$this->_email','$this->_password','$this->_id_province')");
    }
    function delete_user()
    {

    }

    function request_query($query)
    {
      return  $this->_db_connect->query($query);  
    }
}

?>