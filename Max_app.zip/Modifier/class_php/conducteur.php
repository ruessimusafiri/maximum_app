<?php

class conducteur{


  public function card($id){
    return $st= $this->request_query("SELECT * FROM `formulaire` WHERE id='$id'");
  }

    public function load_conducteur(){
      return $st= $this->request_query("SELECT * FROM `formulaire`");
    }
    public function load_conducteur_id($id){
      return $st= $this->request_query("SELECT * FROM `formulaire` WHERE id='$id'");
    }
    public function confirmer_paiement($id_p,$preuve,$date){
      return $st= $this->request_query("INSERT INTO `confirmer_paiement`(`id_proprietaire`, `preuve_paiement`, `date_add`) 
      VALUES ('$id_p','$preuve','$date')");
    }
    public function plaque_immatriculation($id_p,$plaque,$date){
      return $st= $this->request_query("INSERT INTO `immatriculation`(`id_proprietaire`, `num_plaque`, `date_add`) 
      VALUES ('$id_p','$plaque','$date')");
    }
    public function ver_paiement($id){
      return $st= $this->request_query("SELECT * FROM `confirmer_paiement` WHERE id_proprietaire='$id'");
    }
    //Carte
     
    public function ver_imm($id){
      return $st= $this->request_query("SELECT * FROM `immatriculation` WHERE id_proprietaire='$id'");
    }

    public function load_plaque($id){
      return $st= $this->request_query("SELECT * FROM `immatriculation` WHERE id_proprietaire='$id'");
    }

    function Filter($query){
      return $rs=$this->request_query("select * from formulaire WHERE  concat(nom,postnom,lieu_naissance,nationalite,numero_id) like '%".$query."%'");
    }

    public function request_query($query){
        $connect=new PDO('mysql:host=localhost;dbname=seim;charset=utf8','root','');
        $st=$connect->query($query); 
        return $st; 
    }
}

?>