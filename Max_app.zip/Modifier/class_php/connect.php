<?php 

	/* 
	Configuration
	fill those varaibles with your data
// 	*/
 
// 	 $DB_SERVER = "localhost"; 
// 	 $DB_USER = "root"; 
// 	 $DB_PASS = ""; 
// 	 $DB_DATABASE = "saemape_db"; 

// /******************************************************************/
 
// 	 try { 
// 	 $connect =  new PDO("mysql:host=$DB_SERVER; dbname=$admin", $DB_USER,$DB_PASS); 
// 	 } 
 
// 	 catch (PDOException $e) { 

// 	 	// if (empty($admin)) {
// 	 	// 	die("<strong>Database Error..! </strong><a href='install'>Start installation</a>") ;
// 	 	// } else {
// 	 	// 	die("<strong>Database Error..! </strong>") ;
// 	 	// }
	 	 
// 	 } 
 
// 	 // $connect->query("set charcter_set_server = 'utf8'"); 
// 	 // $connect->query("set names'utf8' "); 
		try { 
			$connect=new PDO('mysql:host=localhost;dbname=seim;charset=utf8','root','');
 
		 } 
	 
		 catch (PDOException $e) { 
	
		 	// if (empty($admin)) {
		 	// 	die("<strong>Database Error..! </strong><a href='install'>Start installation</a>") ;
		 	// } else {
		 	// 	die("<strong>Database Error..! </strong>") ;
		 	// }
			  
		 } 
	 	  
?>