 
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.png" />

    <title>Artisanal</title>

   <!-- Bootstrap core CSS -->
    <link href="css2/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css2/bootstrap-theme.min.css" rel="stylesheet">
   

    
     <link rel="stylesheet" href="css2/style.css" rel="stylesheet">
     <link rel="stylesheet" href="css2/Normalize.css" rel="stylesheet">
     <link rel="stylesheet" href="css2/font-awesome/css/font-awesome.min.css">
     <script src="js2/jquery-1.11.3.min.js"></script>
  
  <script src="js2/bootstrap.min.js"></script>

    

    

     
        
  </head>
<body>


<?php 
 
  require_once "class_php/connect.php";
include 'nav.php';

 
 ?> 




<div class="container mainbg" style="margin-top:10px;">
<br><a class="return" href="accueil.php"><i class="glyphicon glyphicon-arrow-left"></i> Retour</a>

    <h1 class="h1_title" style="background-color:gray;">Utilisateurs</h1>
    <hr> <br>

<?php 
if (isset($_POST['submit'])) {
   
  $malade=htmlspecialchars($_POST['malade']);
  $examen=htmlspecialchars($_POST['examen']);
  $observation=htmlspecialchars($_POST['observation']);
  $date=htmlspecialchars($_POST['date']);
  $frais =htmlspecialchars($_POST['frais']);
 
  
  
  
  $ins_medecins=$connect->prepare("INSERT INTO `laboratoire` (`id_labo`, `type_examen`, `observation_labo`, `date_examen`, `frais_examen`, `malade_id_malade`) VALUES (NULL, :examen, :observation, :date, :frais, :malade)");
  $ins_medecins->bindParam(':examen' ,$examen , PDO::PARAM_STR);
  $ins_medecins->bindParam(':observation' ,$observation, PDO::PARAM_STR);
  $ins_medecins->bindParam(':date' ,$date, PDO::PARAM_STR);
  $ins_medecins->bindParam(':frais' ,$frais , PDO::PARAM_STR);
  $ins_medecins->bindParam(':malade' ,$malade, PDO::PARAM_STR);
  $ins_medecins->execute();
  
 

  if (isset($ins_medecins)) {
    echo "<div class='alert alert-success center' style='width: 90%; margin: auto;'><p>Ajout avec sucees</p></div><br><br>"; 
  }

  else {
   echo "<div class='alert alert-danger center' style='width: 90%; margin: auto;'><p>Error d'ajout</p></div><br><br>";     
  }

echo "<meta http-equiv='refresh' content='5; url = laboratoire.php' />";

 } 

?>

    <div class="clear"></div>
    <div class="row col-md-10 col-md-offset-1">

    
    

        <!-- <li class="nav-item">
          <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Cooperative</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" data-toggle="tab" href="#laboratoire" role="tab"> Négociant</a>
        </li> -->
        
 <!-- details -->
  

 <!----------------------------------------tab2---------------------------------------------------------------------------->

<div class="modal fade" id="artisanal"> 
     <div class="modal-dialog">    
         <div class="modal-content">      
             <div class="modal-header">
<button type="button" class="close" data-dismiss="modal">x</button>        
<h4 class="modal-title">Nouveau utilisateur</h4>      
</div>      
<div class="modal-body">  
<form id="formID" action="" method="post"  enctype="multipart/form-data">  
           
           <!-- <img id="avatar" class="editable img-responsive" alt="Alex's Avatar" src="assets/images/avatars/profile-pic.jpg" /> -->
         
           
            <!-- <label style="font-size:23px;">1. Information d'utilisateur </label> -->
     
                    
 
</div> <div class="modal-footer">
    <form action="" method="post">
                                     

        <div class="input-group">
        <span class="input-group-addon"><i class="fa fa-envelope"></i></span>
        <input type="text" class="form-control" placeholder="Email" name="email" required="">
        </div> <br>

        <div class="input-group">
        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
        <input type="password" class="form-control" placeholder="Mot de passe" name="password" required="">
        </div>
        <br>
        
        <div class="input-group">
        <span class="input-group-addon"><i class="fa fa-lock"></i></span>
        <input type="password" class="form-control" placeholder="Confirmer Mot de passe" name="password2" required="">
        </div>
        <br>

<label class="">Province <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label>
<div class="input-group">
<span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
<select name="province" class="form-control validate[required]">
<option selected="selected" value="">Selectionnée</option>
<?php 

require_once 'class_php/connect.php';

$stmt_find_medecins = $connect->query("SELECT * FROM `province`");

while ($find_medecins_row = $stmt_find_medecins->fetch()) {
$fetch_medecins_id =$find_medecins_row['id'];
$fetch_province = $find_medecins_row ['province'];


echo '<option value="'.$fetch_medecins_id.'">'.$fetch_province.'</option>';

} 

?> 
</select>
</div><br>

<div class="input-group">
        <span class="input-group-addon"><i class="fa fa-book"></i></span>
        <input type="text" class="form-control" placeholder="Site" name="site" required="">
        </div>
        <br>



<button type="submit" class="btn btn-primary" name="save_user">ENREGISTRER</button>
        
</form>             
</div>   
  
 </div>  
</div> 
</div>

<?php

require_once 'class_php/utilisateur.php';
require_once 'class_php/connect.php';

$user=new utilisateur($connect);

if(isset($_POST['save_user'])){

    $user->_email=$_POST['email'];
    $user->_password=$_POST['password'];
    $user->_id_province=$_POST['province'];
    $user->_site=$_POST['site'];
    $user->_level='0'; 
    $user->new_user(); 
    
    echo "<div class='alert alert-success center' style='width: 90%; margin: auto;'><p>Succés</p></div><br><br>"; 
    echo '<script type="text/javascript"> window.location.href += "#success"; </script>';
    echo "<meta http-equiv='refresh' content='1; url = utilisateur.php' />";

}

?>
 

 <div class=" " role=" ">
        <div class="tab-pane active" id="home" role="tabpanel">
        <br>
        <button  data-toggle="modal" href="#artisanal"    class="btn btn-primary" name="btn">Nouveau utilisateur</button> <br>
        <form method="post" action=""> 

<br>
<div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-search"></i></span>
                  <input name="search" type="text" placeholder="recherche rapide" class="form-control validate[required]" />
               </div><br>


               
</form>
               
        
<table class="table table-striped table-bordered">
    <tr class="tr-table">
      <th>Email user</th>
      <th>Province</th>
      <th>Site</th>
       
      
     <th colspan="2">Action</th>
    </tr>
<div class="row container">

<?php

require_once 'class_php/province_class.php';
require_once 'class_php/connect.php';
require_once 'class_php/utilisateur.php';

$user=new utilisateur($connect); 
$province= new province($connect);   
$rs=$user->load_user();

while ($r=$rs->fetch()) {
  # code...

  ?>

  <tr>
  <td><?php echo $r['username'] ?></td>
  <td> <?php echo  $province->get_province($r['id_province']) ;?> </td>
  <td> <?php echo  $r['site'];?> </td>
 
  <td><a  data-toggle="modal" href="#infos"  class="btn btn-default"> <i class="fa fa-edit"></i> </a></td>
  <td><a href="utilisateur.php?delete=<?php echo $r['id']; ?>" class="btn btn-default"> <i class="fa fa-trash"></i> </a></td>
  </tr>


<?php
}
?> 

<?php
 require_once 'class_php/province_class.php';
 require_once 'class_php/connect.php';
 require_once 'class_php/utilisateur.php';
 
 $user=new utilisateur($connect);


if(isset($_GET['delete'])){
 $user->_id=$_GET['delete'];
 $user->delete_user();
 

}

?>

</div>

</table>
 </div>
 
 <br>
   
 <!-- <?php include 'footer.php'; ?>                            -->
 <script src="js/bootstrap.min.js"></script>          
<script src="js/popper.min.js"></script>
<script src="js/jquery-slim.min.js"></script>
<script src="js/tab.js"></script>
<script src="js/util.js"></script>


  </body>
</html>
