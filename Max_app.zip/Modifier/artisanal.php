 
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="favicon.png" />

    <title>Artisanal</title>

   <!-- Bootstrap core CSS -->
    <link href="css2/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css2/bootstrap-theme.min.css" rel="stylesheet">
   

    
     <link rel="stylesheet" href="css2/style.css" rel="stylesheet">
     <link rel="stylesheet" href="css2/Normalize.css" rel="stylesheet">
     <link rel="stylesheet" href="css2/font-awesome/css/font-awesome.min.css">
     <script src="js2/jquery-1.11.3.min.js"></script>
  
  <script src="js2/bootstrap.min.js"></script>

    

    

     
        
  </head>
<body>


<?php 
 
  require_once "class_php/connect.php";
include 'nav.php';

 
 ?> 




<div class="container mainbg" style="margin-top:10px;">
<br><a class="return" href="accueil.php"><i class="glyphicon glyphicon-arrow-left"></i> Retour</a>

    <h1 class="h1_title" style="background-color:gray;">Proprietaire</h1>
    <hr> <br>

<?php 
if (isset($_POST['submit'])) {
   
  $malade=htmlspecialchars($_POST['malade']);
  $examen=htmlspecialchars($_POST['examen']);
  $observation=htmlspecialchars($_POST['observation']);
  $date=htmlspecialchars($_POST['date']);
  $frais =htmlspecialchars($_POST['frais']);
 
  
  
  
  $ins_medecins=$connect->prepare("INSERT INTO `laboratoire` (`id_labo`, `type_examen`, `observation_labo`, `date_examen`, `frais_examen`, `malade_id_malade`) VALUES (NULL, :examen, :observation, :date, :frais, :malade)");
  $ins_medecins->bindParam(':examen' ,$examen , PDO::PARAM_STR);
  $ins_medecins->bindParam(':observation' ,$observation, PDO::PARAM_STR);
  $ins_medecins->bindParam(':date' ,$date, PDO::PARAM_STR);
  $ins_medecins->bindParam(':frais' ,$frais , PDO::PARAM_STR);
  $ins_medecins->bindParam(':malade' ,$malade, PDO::PARAM_STR);
  $ins_medecins->execute();
  
 

  if (isset($ins_medecins)) {
    echo "<div class='alert alert-success center' style='width: 90%; margin: auto;'><p>Ajout avec sucees</p></div><br><br>"; 
  }

  else {
   echo "<div class='alert alert-danger center' style='width: 90%; margin: auto;'><p>Error d'ajout</p></div><br><br>";     
  }

echo "<meta http-equiv='refresh' content='5; url = laboratoire.php' />";

 } 

?>

    <div class="clear"></div>
    <div class="row col-md-10 col-md-offset-1">

    
    

        <!-- <li class="nav-item">
          <a class="nav-link" data-toggle="tab" href="#profile" role="tab">Cooperative</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" data-toggle="tab" href="#laboratoire" role="tab"> Négociant</a>
        </li> -->
        
 <!-- details -->
  

 <!----------------------------------------tab2---------------------------------------------------------------------------->

<div class="modal fade" id="artisanal"> 
     <div class="modal-dialog">    
         <div class="modal-content">      
             <div class="modal-header">
<button type="button" class="close" data-dismiss="modal">x</button>        
<h4 class="modal-title">Nouveau proprietaire</h4>      
</div>      
<div class="modal-body">  
<form id="formID" action="" method="post"  enctype="multipart/form-data">  
           
           <!-- <img id="avatar" class="editable img-responsive" alt="Alex's Avatar" src="assets/images/avatars/profile-pic.jpg" /> -->
         
           
            <!-- <label style="font-size:23px;">1. Information d'utilisateur </label> -->
            <br>  
         <div class="row">
           <div class="col-md-4"> 
             <label for="">Importer la photo</label>
           <input type="file" placeholder="importer le fichier" name="img" requred="" class="form-control" required=""> 
           </div> 
         </div><br>
            <div class="row">
              <div class="col-md-6">
                  <!-- <label class=""> <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input name="nom" type="text" placeholder="Nom " class="form-control validate[required]" required=""/>
                    </div><br>
      
                     <!-- <label class=""> <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                        <input name="prenom" type="text" placeholder="Prenom " class="form-control validate[required]" required=""/>
                    </div><br>
              </div>
              <div class="col-md-6">
                  <!-- <label class=""> <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
                  <div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                      <select name="sexe" class="form-control">
                      <option>Sexe</option>
                      <option>M</option>
                      <option>F</option>
                      </select>
                  </div><br>
                   
                  <!-- <label class=""> <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
                  <div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
                      <input name="lieu" type="text" placeholder="Lieu de naissance " class="form-control validate[required]" required="" />
                  </div><br>
              </div>
              
            </div>
              <div class="row">
                <div class="col-md-6">
                  <!-- <label class=""> <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
                  <div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
                      <input name="nationalite" type="text" placeholder="Nationalite " class="form-control validate[required]" required="" />
                  </div><br>
                  
                  <!-- <label class="">Type d'identification : <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
                  <div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                      <select name="type_id" class="form-control">
                      <option>Type identification</option>
                      <option>Carte electeur</option>
                      <option>Passport</option>
                      <option>Permis de conduire</option>
                      </select>
                  </div><br>
              </div>
              <div class="col-md-6">
                <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
                  <input name="num_id" type="text" placeholder="Numero de l'identité " class="form-control validate[required]"  required="" />
              </div><br>
              
              </div>
              <div class="col-md-6">
                <div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
                  <input name="telephone" type="text" placeholder="Telephone " class="form-control validate[required]" required="" />
              </div><br>
              </div>
              </div>
            <div class="row">
               
      
              <div class="col-md-6"> 
                  <!-- <label class=""> <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
                  <div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
                      <input name="adresse" type="text" placeholder="Adresse physique " class="form-control validate[required]" required="" />
                  </div><br>
              </div>
            </div>
                 <p style="font-size:20px;">Information sur la moto  </p>
                <div class="row">
                  <div class="col-md-6">
                      <!-- <label class=""><span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
                      <div class="input-group">
                          <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
                          <input name="marque" type="text" placeholder="Marque " class="form-control validate[required]" required="" />
                      </div><br>
        
                      <!-- <label class=""> <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
                      <div class="input-group">
                          <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
                          <input name="num_chassis" type="text" placeholder="Numero chassis" class="form-control validate[required]" required="" />
                      </div><br>
                  </div>
                  <div class="col-md-6">
                      <!-- <label class=""> <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
                        <input name="annee_fab" type="text" placeholder="Année fabrication " class="form-control validate[required]" required="" />
                    </div><br>
      
                    <!-- <label class=""><span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
                        <input name="annee_circulation" type="text" placeholder="Année mise en circulation " class="form-control validate[required]" required="" />
                    </div><br>
                  </div>
                 
      
                  <div class="col-md-6">
                  <!-- <label class="">Province : <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label>
                      <div class="input-group">
                          <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
                          <input name="province" type="text" placeholder="" class="form-control validate[required]" required="" />
                      </div><br> -->
              <!-- <label class=""><span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                        <select name="province" class="form-control validate[required]">
                        <option selected="selected" value="">Province </option>
       <?php 
      
      require_once 'class_php/connect.php';
      
      $stmt_find_medecins = $connect->query("SELECT * FROM `province`");
      
      while ($find_medecins_row = $stmt_find_medecins->fetch()) {
        $fetch_medecins_id =$find_medecins_row['id'];
        $fetch_province = $find_medecins_row ['province'];
        
      
        echo '<option value="'.$fetch_medecins_id.'">'.$fetch_province.'</option>';
      
      } 
      
      ?> 
                        </select>
                    </div><br>
                  </div>
      
                  <div class="col-md-6">
                    <!-- <label class=""><span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
                    <div class="input-group">
                        <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
                        <input name="type" type="text" placeholder="Type " class="form-control validate[required]" required="" />
                    </div><br>
                </div>
                </div> 

                <div class="row">
                  
                </div>
      
      <div class="row">
      <div class="col-md-6">
      <!-- <label class=""> <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
      <input name="couleur" type="text" placeholder="Couleur " class="form-control validate[required]" required="" />
       </div><br>
      </div>
      <div class="col-md-6">
      <!-- <label class=""> <span style="color:red; font-weight: bold; font-family: Arial, sans-serif ;">(*)</span></label> -->
      <div class="input-group">
      <span class="input-group-addon"><i class="glyphicon glyphicon-book"></i></span>
      <input name="moteur" type="text" placeholder="Numero moteur " class="form-control validate[required]" required="" />
       </div><br>
      </div>
      </div>
                    
 
</div> <div class="modal-footer">
          
<button class="btn btn-info" name="submit22" >ENREGISTRER </button> 
                     
</div>   
 </form>  
 </div>  
</div> 
</div>
<?php 
$connect=new PDO('mysql:host=localhost;dbname=seim;charset=utf8','root','');
if (isset($_POST['submit22'])) {

 //genere pdf 


  $folder = 'images/'; 
   $file_image=$_FILES['img']['name'];;
   $filetmpname = $_FILES['img']['tmp_name']; 
   $save_photo=$folder.'photo'.$_POST['num_id'].$file_image;   
   move_uploaded_file($filetmpname, $save_photo); 
   $nom=htmlspecialchars($_POST['nom']);
 $prenom=htmlspecialchars($_POST['prenom']);
 $sexe=htmlspecialchars($_POST['sexe']);
 $lieu_naissance=htmlspecialchars($_POST['lieu']);
 //$tel_malade=htmlspecialchars($_POST['tel']);
 $nationalite=htmlspecialchars($_POST['nationalite']);
 $type_id=htmlspecialchars($_POST['type_id']);
 $num_id=htmlspecialchars($_POST['num_id']);
 $telephone=htmlspecialchars($_POST['telephone']);
 $adresse=htmlspecialchars($_POST['adresse']);
 $type_id=htmlspecialchars($_POST['type_id']);
 $marque=htmlspecialchars($_POST['marque']);
 $annee_fab=htmlspecialchars($_POST['annee_fab']);
 $anne_cirulation=htmlspecialchars($_POST['annee_circulation']);
 $type_moto=htmlspecialchars($_POST['type']);
 $chassis=htmlspecialchars($_POST['num_chassis']);
 $province=htmlspecialchars($_POST['province']);
 $couleur=htmlspecialchars($_POST['couleur']);
 $moteur=htmlspecialchars($_POST['moteur']);
 $date_add=date('d:m:yy');

 $ins_malade=$connect->prepare("INSERT INTO `formulaire`(`nom`, `postnom`, `sexe`, `lieu_naissance`, `nationalite`, `type_identification`, `numero_id`, `adresse_physique`, `marque`, `numero_chassis`, `annee_fab`, `annee_circulation`, `type_moto`, `province`, `file_picture`,`couleur`,`moteur`,`date_add`) 
 VALUES (:nom,:prenom,:sexe,:lieu_naissance,:nationalite,:type_identification,:numero_id,:adresse_physique,:marque,:numero_chassis,:annee_fab,:annee_circulation,:type_moto,:province,:picture,:couleur,:moteur,:date_add)");
 $ins_malade->bindParam(':nom' ,$nom, PDO::PARAM_STR);
 $ins_malade->bindParam(':prenom' ,$prenom , PDO::PARAM_STR);
 $ins_malade->bindParam(':sexe' ,$sexe, PDO::PARAM_STR);
 $ins_malade->bindParam(':lieu_naissance',$lieu_naissance, PDO::PARAM_STR);
 $ins_malade->bindParam(':nationalite',$nationalite, PDO::PARAM_STR); 
 //$ins_malade->bindParam(':tel' ,$tel_malade , PDO::PARAM_STR);
 $ins_malade->bindParam(':type_identification',$type_id, PDO::PARAM_STR);
 $ins_malade->bindParam(':numero_id',$num_id, PDO::PARAM_STR);
 $ins_malade->bindParam(':adresse_physique',$adresse , PDO::PARAM_STR);
 $ins_malade->bindParam(':marque',$marque, PDO::PARAM_STR);
 $ins_malade->bindParam(':numero_chassis',$chassis, PDO::PARAM_STR);
 $ins_malade->bindParam(':annee_fab',$annee_fab, PDO::PARAM_STR);
 $ins_malade->bindParam(':annee_circulation',$anne_cirulation, PDO::PARAM_STR);
 $ins_malade->bindParam(':type_moto',$type_moto,PDO::PARAM_STR);
 $ins_malade->bindParam(':province',$province,PDO::PARAM_STR);
 $ins_malade->bindParam(':picture',$save_photo,PDO::PARAM_STR);
 $ins_malade->bindParam(':couleur',$couleur,PDO::PARAM_STR);
 $ins_malade->bindParam(':moteur',$moteur,PDO::PARAM_STR);
 $ins_malade->bindParam(':date_add',$date_add,PDO::PARAM_STR);
 $ins_malade->execute();


  
 if (isset($ins_malade)) {
   echo "<div class='alert alert-success center' style='width: 90%; margin: auto;'><p>Ajout avec sucees</p></div><br><br>
 <meta http-equiv='refresh' content='1; url = artisanal.php' />
 "; 
 }

 else {
  echo "<div class='alert alert-danger center' style='width: 90%; margin: auto;'><p>Error  </p></div><br><br>";     
 }


} 

?>

 <div class=" " role=" ">
        <div class="tab-pane active" id="home" role="tabpanel">
        <br>
        <button  data-toggle="modal" href="#artisanal"    class="btn btn-primary" name="btn">Nouveau proprietaire</button> <br>
        <form method="post" action=""> 

<br>
<div class="input-group">
                  <span class="input-group-addon"><i class="glyphicon glyphicon-search"></i></span>
                  <input name="search" type="text" placeholder="recherche rapide" class="form-control validate[required]" />
               </div><br>


               
</form>
         
              
        
        
          <table class="table table-striped table-bordered">
          <tr class="tr-table">
          <th>Photo</th>
            <th>Nom & Prenom</th>
            <th>Sexe</th>
            <th>N° Identité</th>
            <th>Adresse</th>
            
            <th colspan="3">Details</th>
          </tr>



          

          <?php

require_once 'class_php/conducteur.php';

						  $conducteur=new conducteur();

						 if(isset($_POST['search'])){
							 $search=$_POST['search'];
						 $result=$conducteur->Filter($search);
						 }else{
						 $result=$conducteur->load_conducteur();
 }
  while($pst=$result->fetch()){

        ?>
<tr>
        <td> <img   src="<?php  echo $pst['file_picture']; ?>"  width="60"  style="height:60px;"/></td>
        <td> <?php  echo $pst['nom'].' '.$pst['postnom']; ?> </td>
        <td> <?php  echo $pst['sexe']; ?> </td>
        <td> <?php  echo $pst['numero_id']; ?></td>
        <td><?php  echo $pst['adresse_physique']; ?></td>
        <td><a   href="view.php?id=<?php  echo $pst['id']; ?>"  ><i class="fa fa-eye"></i> </a></td>
          </tr>
  
          <div class="modal fade" id="details<?php  echo $pst['id']; ?>"> 
            <div class="modal-dialog">    
                <div class="modal-content">      
                    <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">x</button>        
          <h4 class="modal-title">Details <?php  echo $pst['id']; ?></h4>      
          </div>     
         
          <div class="modal-body">  
            <img   src="<?php  echo $pst['file_picture']; ?>"  width="130"style="height:110px;" />
            <br> <br>
            
          
          </div> 
          
          <div class="modal-footer">
          <!--        
          <button class="btn btn-info" name="submit22" >ENREGISTRER </button>  -->
                            
          </div>   
           
          </div>  
          </div> 
          </div>
        <?php

    
      }

?>
          
          
    
              
      </table>
 </div>
 
 <br>
   
 <!-- <?php include 'footer.php'; ?>                            -->
 <script src="js/bootstrap.min.js"></script>          
<script src="js/popper.min.js"></script>
<script src="js/jquery-slim.min.js"></script>
<script src="js/tab.js"></script>
<script src="js/util.js"></script>


  </body>
</html>
