<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Session !</title>

    <link href="css2/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="css2/bootstrap-theme.min.css" rel="stylesheet">
   

    
     <link rel="stylesheet" href="css/style.css" rel="stylesheet">
     <link rel="stylesheet" href="css/Normalize.css" rel="stylesheet">
     <link rel="stylesheet" href="fonta/css/all.css">


   

      <script src="js2/jquery-1.11.3.min.js"></script>

    

     
</head>
<style type="text/css">  
   /* Style pour l'exemple*/  
       article.col-sm-10, nav.col-sm-2 {  
                 line-height: 100px;     
                  }   
                   </style>  
 </head> 
  <body class="twitter-bg">   
   <div class="container">      
   <header class="row">        
   <div class="col-lg-12">         
           
   </div>      
   </header>      
   <div class="row">       
    <nav class="col-sm-2">      
                 
        </nav>        
        <section class="col-sm-10">       
                   
            <div class="row">           
             <article class="col-sm-8" style="background-color:#fff; border-radius:10px;">    

                    <div class="colo-md-4 col-md-offset-6">

                    <h1 class="fa fa-clock" style="font-size:45px;color:gray;">  </h1>
 
                         
                    </div> 
                   
                   <div class="colo-md-4 col-md-offset-3">
                   <h2 class="text-info">Your session has expired due in activity.</h2>

                   <div class="input-group" style="width:360px;">
                   <span class="input-group-addon"> <i class="fa fa-lock"></i></span>
                   <input type="text" name="" class="form-control" placeholder="Veuillez saisir l'ID !" required="">

                   </div><br>
                   <button type="submit" class="btn btn-info" style="width:360px;" >VALIDER</button><br><br>
                   </div>


                            
              </article>           
               <div class="col-sm-2">              
               <div class="row">              
                 <aside>                 
                             
                     </aside>                
                     <aside>                 
                                   
                       </aside>              
                       </div>            
                       </div>         
                        </div>        
                        </section>      
                        </div>    
                          <footer class="row">      
                            <div class="col-lg-12">          
                                  
                             </div>    
                              </footer>   
                               </div>  
                               </body> 
</html>