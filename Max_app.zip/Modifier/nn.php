<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bulma/css/bulma.css" rel="stylesheet">
    <link href="bulma/css/bulma.min.css" rel="stylesheet">
    <link href="bulma/css/bulma-rtl.css" rel="stylesheet">
    <link rel="stylesheet" href="css/font-awesome/css/font-awesome.min.css">

    <!-- boostrap -->
    <script src="js/bootstrap.min.js"></script>
     
    <title>Login</title>
</head>
<body>
<section class="hero is-primary is-fullheight">
  <div class="hero-body">
    <div class="container">
      <div class="columns is-centered">
        <div class="column is-5-tablet is-4-desktop is-3-widescreen">
          <form  action="index.php" class="box" method="post">
            <div class="field">
              <label for="" class="label">Email</label>
              <div class="control has-icons-left">
                <input name="username" type="text" placeholder="Utilisateur" class="input" required>
                <span class="icon is-small is-left">
                  <i class="fa fa-user"></i>
                </span>
              </div>
            </div>
            <div class="field">
              <label for="" class="label">Password</label>
              <div class="control has-icons-left">
                <input name="password" type="password" placeholder="*******" class="input" required>
                <span class="icon is-small is-left">
                  <i class="fa fa-lock"></i>
                </span>
              </div>
            </div>
            <div class="field">
              <label for="" class="checkbox">
                <input type="checkbox">
               Remember me
              </label>
            </div>
            <div class="field">
              <button name="login" class="button is-success">
                Login
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</section>
</body>
 
</html>

